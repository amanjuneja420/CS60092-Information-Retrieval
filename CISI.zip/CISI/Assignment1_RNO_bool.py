import pickle
import sys

def read_query_file(filename):
    dict = {}
    with open(filename, "r") as f:
        lines = f.readlines()
        for line in lines:
            id = line.split("\t")[0]
            content = (line.split("\t")[1]).split()
            dict[id] = content
    return dict

def merge(sets):
    merged_set = set.intersection(*sets)
    return list(merged_set)

def retrieve_docs(inverted_index, query_list):
    sets = []
    for query in query_list:
        try:
            docs_query = set(inverted_index[query])
        except:
            docs_query = set([])
        # print(docs_query)
        sets.append(docs_query)
    # print(sets)
    merged_set = merge(sets)
    return list(merged_set)

def main():
    model_path = sys.argv[1]
    query_file_path = sys.argv[2]

    with open(model_path, 'rb') as f:
        inverted_index = pickle.load(f)

    query_dict = read_query_file(query_file_path)


    with open("Assignment1_RNO_results.txt", "w") as f:
        for q_id, q_t in query_dict.items():
            merged_list = retrieve_docs(inverted_index, q_t)
            final_string = f"{q_id}:"
            for element in merged_list:
                final_string+=f"{element} "
            f.write(f"{final_string}\n")

if __name__=="__main__":
    main()
            

