import re
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import sys

# Make sure to download the necessary NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Initialize the lemmatizer and stop words list
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    # Remove punctuation and tokenize
    text = re.sub(r'[^\w\s]', '', text)
    tokens = word_tokenize(text.lower())
    
    # Remove stopwords and lemmatize
    tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    
    return tokens

def parse_all_file(file_path):
    documents = {}
    current_id = None
    capture_text = False
    current_text = []

    with open(file_path, 'r') as f:
        # breakpoint()
        for line in f:
            if line.startswith('.I'):
                # Save the current document before starting a new one
                if current_id:
                    documents[current_id] = ' '.join(current_text)
                # Start a new document
                current_id = line.split()[1]
                current_text = []
                capture_text = False
            elif line.startswith('.W'):
                # Start capturing text after .W marker
                capture_text = True
            elif line.startswith('.X'):
                # Stop capturing text at .X marker
                capture_text = False
            elif capture_text:
                current_text.append(line.strip())

        # Save the last document
        if current_id:
            documents[current_id] = ' '.join(current_text)

    return documents


def main():
    query_file_path = sys.argv[1]
    # Replace 'path_to_file.all' with the path to your .ALL file
    documents = parse_all_file(query_file_path)
    # Display the extracted text for each document
    with open("queries_1.txt", 'w') as f:
        # breakpoint()
        for doc_id, text in documents.items():
            tokens = preprocess_text(text)
            line = f"{doc_id}\t"
            for token in tokens:
                line += f"{token} "
            f.write(f"{line}\n")

if __name__=="__main__":
    main()
    


